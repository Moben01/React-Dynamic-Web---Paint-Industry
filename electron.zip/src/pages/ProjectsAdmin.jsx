import { useMemo, useRef, useState } from 'react'
import {
  Eye,
  EyeOff,
  ImagePlus,
  LayoutTemplate,
  Pencil,
  Plus,
  RotateCcw,
  Save,
  Star,
  Trash2,
  X,
} from 'lucide-react'
import {
  loadProjectsData,
  projectCategoryOptions,
  resetProjectsData,
  saveProjectsData,
} from '../data/projectsStore'
import './ProjectsAdmin.css'

const MAX_IMAGE_SIZE = 3 * 1024 * 1024

const emptyForm = {
  id: '',
  title: '',
  category: 'exterior',
  categoryLabel: 'نمای بیرونی',
  location: '',
  year: String(new Date().getFullYear()),
  status: 'تکمیل‌شده',
  client: '',
  area: '',
  description: '',
  image: '',
  alt: '',
  objectPosition: 'center',
  link: '/projects',
  featured: false,
  order: 1,
  active: true,
}

function ProjectsAdmin({ searchTerm = '' }) {
  const [data, setData] = useState(loadProjectsData)
  const [activeSection, setActiveSection] = useState('content')
  const [form, setForm] = useState(emptyForm)
  const [modalOpen, setModalOpen] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState(null)
  const [error, setError] = useState('')
  const fileRef = useRef(null)

  const persist = (nextData, message = '') => {
    setData(nextData)
    saveProjectsData(nextData)
    if (message) window.alert(message)
  }

  const updateSection = (field, value) => {
    setData((current) => ({
      ...current,
      section: {
        ...current.section,
        [field]: value,
      },
    }))
  }

  const saveSection = () => {
    persist(data, 'متن‌های صفحه پروژه‌ها ذخیره شد.')
  }

  const openNew = () => {
    setForm({
      ...emptyForm,
      order: data.projects.length + 1,
      featured: data.projects.length === 0,
    })
    setError('')
    setModalOpen(true)
  }

  const openEdit = (project) => {
    setForm({ ...emptyForm, ...project })
    setError('')
    setModalOpen(true)
  }

  const closeModal = () => {
    setModalOpen(false)
    setForm(emptyForm)
    setError('')
    if (fileRef.current) fileRef.current.value = ''
  }

  const updateForm = (field, value) => {
    setForm((current) => ({
      ...current,
      [field]: value,
    }))
    setError('')
  }

  const changeCategory = (value) => {
    const category =
      projectCategoryOptions.find((item) => item.value === value) ||
      projectCategoryOptions[0]

    setForm((current) => ({
      ...current,
      category: category.value,
      categoryLabel: category.label,
    }))
  }

  const selectImage = (event) => {
    const file = event.target.files?.[0]
    event.target.value = ''

    if (!file) return

    if (!file.type.startsWith('image/')) {
      setError('فقط فایل تصویری انتخاب کنید.')
      return
    }

    if (file.size > MAX_IMAGE_SIZE) {
      setError('حجم عکس باید کمتر از ۳ مگابایت باشد.')
      return
    }

    const reader = new FileReader()
    reader.onload = () => updateForm('image', String(reader.result || ''))
    reader.onerror = () => setError('خواندن عکس موفق نشد.')
    reader.readAsDataURL(file)
  }

  const submit = (event) => {
    event.preventDefault()

    if (!form.title.trim()) {
      setError('عنوان پروژه الزامی است.')
      return
    }

    if (!form.image.trim()) {
      setError('عکس پروژه الزامی است.')
      return
    }

    const record = {
      ...form,
      id: form.id || `project-${Date.now()}`,
      title: form.title.trim(),
      categoryLabel: form.categoryLabel.trim(),
      location: form.location.trim(),
      year: String(form.year || '').trim(),
      client: form.client.trim(),
      area: form.area.trim(),
      description: form.description.trim(),
      image: form.image.trim(),
      alt: form.alt.trim() || form.title.trim(),
      link: form.link.trim() || '/projects',
      order: Number(form.order) || data.projects.length + 1,
      featured: Boolean(form.featured),
      active: Boolean(form.active),
    }

    let nextProjects = form.id
      ? data.projects.map((project) =>
          String(project.id) === String(form.id) ? record : project,
        )
      : [...data.projects, record]

    if (record.featured) {
      nextProjects = nextProjects.map((project) => ({
        ...project,
        featured: String(project.id) === String(record.id),
      }))
    }

    persist(
      {
        ...data,
        projects: nextProjects,
      },
      form.id ? 'پروژه ویرایش شد.' : 'پروژه جدید ثبت شد.',
    )

    closeModal()
  }

  const toggleActive = (projectId) => {
    persist({
      ...data,
      projects: data.projects.map((project) =>
        String(project.id) === String(projectId)
          ? { ...project, active: project.active === false }
          : project,
      ),
    })
  }

  const makeFeatured = (projectId) => {
    persist({
      ...data,
      projects: data.projects.map((project) => ({
        ...project,
        featured: String(project.id) === String(projectId),
      })),
    })
  }

  const confirmDelete = () => {
    if (!deleteTarget) return

    const nextProjects = data.projects
      .filter(
        (project) =>
          String(project.id) !== String(deleteTarget.id),
      )
      .map((project, index) => ({
        ...project,
        order: index + 1,
      }))

    if (
      deleteTarget.featured &&
      nextProjects.length &&
      !nextProjects.some((project) => project.featured)
    ) {
      nextProjects[0] = {
        ...nextProjects[0],
        featured: true,
      }
    }

    persist(
      {
        ...data,
        projects: nextProjects,
      },
      'پروژه حذف شد.',
    )

    setDeleteTarget(null)
  }

  const resetAll = () => {
    if (
      !window.confirm(
        'تمام معلومات پروژه‌ها به حالت اولیه برگردد؟',
      )
    ) {
      return
    }

    setData(resetProjectsData())
  }

  const filteredProjects = useMemo(() => {
    const query = searchTerm.trim().toLowerCase()

    return [...data.projects]
      .filter((project) =>
        `${project.title} ${project.categoryLabel} ${project.location} ${project.client} ${project.status}`
          .toLowerCase()
          .includes(query),
      )
      .sort(
        (first, second) =>
          Number(first.order || 0) -
          Number(second.order || 0),
      )
  }, [data.projects, searchTerm])

  return (
    <div className="projects-admin">
      <div className="projects-admin-tabs">
        <button
          type="button"
          className={activeSection === 'content' ? 'active' : ''}
          onClick={() => setActiveSection('content')}
        >
          <LayoutTemplate size={18} />
          متن‌های صفحه
        </button>

        <button
          type="button"
          className={activeSection === 'projects' ? 'active' : ''}
          onClick={() => setActiveSection('projects')}
        >
          <ImagePlus size={18} />
          لیست پروژه‌ها
        </button>

        <button
          type="button"
          className="reset"
          onClick={resetAll}
        >
          <RotateCcw size={16} />
          بازگردانی معلومات اولیه
        </button>
      </div>

      {activeSection === 'content' && (
        <section className="projects-admin-section-card">
          <header>
            <div>
              <h3>محتوای بالای صفحه پروژه‌ها</h3>
              <p>
                تمام عنوان‌ها، توضیحات و نوشته پس‌زمینه این بخش را مدیریت کنید.
              </p>
            </div>
          </header>

          <div className="projects-admin-section-form">
            <label>
              <span>نوشته کوچک بالا</span>
              <input
                value={data.section.eyebrow}
                onChange={(event) =>
                  updateSection('eyebrow', event.target.value)
                }
              />
            </label>

            <label>
              <span>قسمت اول عنوان</span>
              <input
                value={data.section.title}
                onChange={(event) =>
                  updateSection('title', event.target.value)
                }
              />
            </label>

            <label>
              <span>قسمت رنگی عنوان</span>
              <input
                value={data.section.highlight}
                onChange={(event) =>
                  updateSection('highlight', event.target.value)
                }
              />
            </label>

            <label>
              <span>نوشته بزرگ پس‌زمینه</span>
              <input
                value={data.section.backgroundWord}
                onChange={(event) =>
                  updateSection('backgroundWord', event.target.value)
                }
                dir="ltr"
              />
            </label>

            <label className="full">
              <span>توضیحات</span>
              <textarea
                rows="4"
                value={data.section.description}
                onChange={(event) =>
                  updateSection('description', event.target.value)
                }
              />
            </label>

            <label className="full">
              <span>متن راهنما پایین اسلایدر</span>
              <input
                value={data.section.hint}
                onChange={(event) =>
                  updateSection('hint', event.target.value)
                }
              />
            </label>

            <label className="full">
              <span>پیام نبودن پروژه</span>
              <input
                value={data.section.emptyMessage}
                onChange={(event) =>
                  updateSection('emptyMessage', event.target.value)
                }
              />
            </label>
          </div>

          <footer>
            <button type="button" onClick={saveSection}>
              <Save size={17} />
              ذخیره متن‌های صفحه
            </button>
          </footer>
        </section>
      )}

      {activeSection === 'projects' && (
        <>
          <div className="projects-admin-toolbar">
            <p>
              پروژه‌های فعال در صفحه پروژه‌ها نمایش داده می‌شوند. پروژه منتخب با نشان ستاره مشخص است.
            </p>

            <button type="button" onClick={openNew}>
              <Plus size={18} />
              پروژه جدید
            </button>
          </div>

          <div className="projects-admin-grid">
            {filteredProjects.map((project) => (
              <article
                key={project.id}
                className={project.active === false ? 'is-disabled' : ''}
              >
                <div className="projects-admin-image">
                  <img
                    src={project.image}
                    alt={project.alt || project.title}
                    style={{
                      objectPosition:
                        project.objectPosition || 'center',
                    }}
                  />

                  <span>{project.year}</span>

                  {project.featured && (
                    <b>
                      <Star size={14} fill="currentColor" />
                      منتخب
                    </b>
                  )}
                </div>

                <div className="projects-admin-content">
                  <small>{project.categoryLabel}</small>
                  <h3>{project.title}</h3>
                  <p>{project.location || 'موقعیت ثبت نشده'}</p>

                  <div>
                    <span>{project.status}</span>
                    <strong>
                      {project.active === false ? 'غیرفعال' : 'فعال'}
                    </strong>
                  </div>
                </div>

                <footer>
                  <button
                    type="button"
                    onClick={() => toggleActive(project.id)}
                    title={
                      project.active === false
                        ? 'فعال‌کردن'
                        : 'غیرفعال‌کردن'
                    }
                  >
                    {project.active === false ? (
                      <EyeOff size={16} />
                    ) : (
                      <Eye size={16} />
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => makeFeatured(project.id)}
                    title="انتخاب به‌عنوان پروژه منتخب"
                  >
                    <Star size={16} />
                  </button>

                  <button
                    type="button"
                    onClick={() => openEdit(project)}
                    title="ویرایش"
                  >
                    <Pencil size={16} />
                  </button>

                  <button
                    type="button"
                    className="danger"
                    onClick={() => setDeleteTarget(project)}
                    title="حذف"
                  >
                    <Trash2 size={16} />
                  </button>
                </footer>
              </article>
            ))}
          </div>

          {!filteredProjects.length && (
            <div className="projects-admin-empty">
              هیچ پروژه‌ای مطابق جستجو پیدا نشد.
            </div>
          )}
        </>
      )}

      {modalOpen && (
        <div
          className="projects-admin-backdrop"
          onMouseDown={closeModal}
        >
          <form
            className="projects-admin-modal"
            onSubmit={submit}
            onMouseDown={(event) => event.stopPropagation()}
          >
            <header>
              <div>
                <h2>
                  {form.id ? 'ویرایش پروژه' : 'افزودن پروژه'}
                </h2>
                <p>تمام معلومات کارت پروژه را وارد کنید.</p>
              </div>

              <button type="button" onClick={closeModal}>
                <X size={20} />
              </button>
            </header>

            <div className="projects-admin-form-layout">
              <aside>
                <button
                  type="button"
                  className="projects-admin-upload"
                  onClick={() => fileRef.current?.click()}
                >
                  {form.image ? (
                    <img
                      src={form.image}
                      alt="پیش‌نمایش پروژه"
                      style={{
                        objectPosition: form.objectPosition,
                      }}
                    />
                  ) : (
                    <span>
                      <ImagePlus size={34} />
                      <strong>انتخاب عکس پروژه</strong>
                      <small>
                        پیشنهاد: ۱۴۰۰ × ۹۰۰، کمتر از ۳MB
                      </small>
                    </span>
                  )}
                </button>

                <input
                  ref={fileRef}
                  type="file"
                  accept="image/webp,image/jpeg,image/png"
                  hidden
                  onChange={selectImage}
                />

                <label>
                  <span>یا آدرس تصویر</span>
                  <input
                    value={form.image}
                    onChange={(event) =>
                      updateForm('image', event.target.value)
                    }
                    placeholder="https://..."
                    dir="ltr"
                  />
                </label>
              </aside>

              <div className="projects-admin-fields">
                <label>
                  <span>عنوان پروژه *</span>
                  <input
                    value={form.title}
                    onChange={(event) =>
                      updateForm('title', event.target.value)
                    }
                  />
                </label>

                <label>
                  <span>دسته‌بندی</span>
                  <select
                    value={form.category}
                    onChange={(event) =>
                      changeCategory(event.target.value)
                    }
                  >
                    {projectCategoryOptions.map((item) => (
                      <option
                        key={item.value}
                        value={item.value}
                      >
                        {item.label}
                      </option>
                    ))}
                  </select>
                </label>

                <label>
                  <span>عنوان دسته‌بندی روی کارت</span>
                  <input
                    value={form.categoryLabel}
                    onChange={(event) =>
                      updateForm(
                        'categoryLabel',
                        event.target.value,
                      )
                    }
                  />
                </label>

                <label>
                  <span>موقعیت</span>
                  <input
                    value={form.location}
                    onChange={(event) =>
                      updateForm('location', event.target.value)
                    }
                  />
                </label>

                <label>
                  <span>سال</span>
                  <input
                    value={form.year}
                    onChange={(event) =>
                      updateForm('year', event.target.value)
                    }
                  />
                </label>

                <label>
                  <span>حالت پروژه</span>
                  <select
                    value={form.status}
                    onChange={(event) =>
                      updateForm('status', event.target.value)
                    }
                  >
                    <option value="تکمیل‌شده">تکمیل‌شده</option>
                    <option value="در حال اجرا">در حال اجرا</option>
                    <option value="متوقف‌شده">متوقف‌شده</option>
                  </select>
                </label>

                <label>
                  <span>مشتری</span>
                  <input
                    value={form.client}
                    onChange={(event) =>
                      updateForm('client', event.target.value)
                    }
                  />
                </label>

                <label>
                  <span>مساحت</span>
                  <input
                    value={form.area}
                    onChange={(event) =>
                      updateForm('area', event.target.value)
                    }
                  />
                </label>

                <label>
                  <span>ترتیب نمایش</span>
                  <input
                    type="number"
                    min="1"
                    value={form.order}
                    onChange={(event) =>
                      updateForm('order', event.target.value)
                    }
                  />
                </label>

                <label>
                  <span>موقعیت عکس</span>
                  <select
                    value={form.objectPosition}
                    onChange={(event) =>
                      updateForm(
                        'objectPosition',
                        event.target.value,
                      )
                    }
                  >
                    <option value="center">وسط</option>
                    <option value="top">بالا</option>
                    <option value="bottom">پایین</option>
                    <option value="left">چپ</option>
                    <option value="right">راست</option>
                  </select>
                </label>

                <label className="is-full">
                  <span>لینک مشاهده جزئیات</span>
                  <input
                    value={form.link}
                    onChange={(event) =>
                      updateForm('link', event.target.value)
                    }
                    dir="ltr"
                    placeholder="/projects"
                  />
                </label>

                <label className="is-full">
                  <span>متن Alt تصویر</span>
                  <input
                    value={form.alt}
                    onChange={(event) =>
                      updateForm('alt', event.target.value)
                    }
                  />
                </label>

                <label className="is-full">
                  <span>توضیحات</span>
                  <textarea
                    rows="4"
                    value={form.description}
                    onChange={(event) =>
                      updateForm(
                        'description',
                        event.target.value,
                      )
                    }
                  />
                </label>

                <label className="check">
                  <input
                    type="checkbox"
                    checked={form.featured}
                    onChange={(event) =>
                      updateForm('featured', event.target.checked)
                    }
                  />
                  <span>پروژه منتخب باشد</span>
                </label>

                <label className="check">
                  <input
                    type="checkbox"
                    checked={form.active}
                    onChange={(event) =>
                      updateForm('active', event.target.checked)
                    }
                  />
                  <span>پروژه فعال باشد</span>
                </label>
              </div>
            </div>

            {error && (
              <p className="projects-admin-error">{error}</p>
            )}

            <footer className="projects-admin-actions">
              <button type="button" onClick={closeModal}>
                انصراف
              </button>

              <button type="submit" className="save">
                <Save size={16} />
                ذخیره پروژه
              </button>
            </footer>
          </form>
        </div>
      )}

      {deleteTarget && (
        <div className="projects-admin-backdrop">
          <div className="projects-admin-delete-modal">
            <span>
              <Trash2 size={25} />
            </span>

            <h3>حذف پروژه</h3>

            <p>
              آیا پروژه «{deleteTarget.title}» حذف شود؟ این عمل قابل برگشت نیست.
            </p>

            <div>
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
              >
                انصراف
              </button>

              <button type="button" onClick={confirmDelete}>
                حذف
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default ProjectsAdmin