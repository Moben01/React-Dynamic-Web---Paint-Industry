import { useMemo, useRef, useState } from 'react'
import TranslateFieldButton from '../components/TranslateFieldButton'
import {
  Check,
  ImagePlus,
  LayoutTemplate,
  PackagePlus,
  Pencil,
  Plus,
  RotateCcw,
  Save,
  Search,
  Star,
  Trash2,
  X,
} from 'lucide-react'
import {
  loadProductsData,
  productCategoryOptions,
  resetProductsData,
  saveProductsData,
} from '../data/productsStore'
import './ProductsAdmin.css'

const emptyProduct = {
  id: null,
  name: '',
  category: 'interior',
  categoryLabel: 'رنگ داخلی',
  description: '',
  sizesText: '',
  finish: '',
  coverage: '',
  image: '',

  colorsText: '',
  selectedColor: '#ff6b1a',

  featured: false,
  active: true,
  order: 1,
}

function ProductsAdmin({ searchTerm = '' }) {
  const [data, setData] = useState(loadProductsData)
  const [section, setSection] = useState('hero')
  const [modalOpen, setModalOpen] = useState(false)
  const [draft, setDraft] = useState(emptyProduct)
  const [deleteTarget, setDeleteTarget] = useState(null)
  const imageInputRef = useRef(null)

  const persist = (nextData, message) => {
    setData(nextData)
    saveProductsData(nextData)
    if (message) window.alert(message)
  }

  const updateHero = (field, value) => {
    setData((current) => ({
      ...current,
      hero: {
        ...current.hero,
        [field]: value,
      },
    }))
  }

  const updateCatalog = (field, value) => {
    setData((current) => ({
      ...current,
      catalog: {
        ...current.catalog,
        [field]: value,
      },
    }))
  }

  const updateHeroStat = (index, field, value) => {
    setData((current) => ({
      ...current,
      hero: {
        ...current.hero,
        stats: current.hero.stats.map((stat, statIndex) =>
          statIndex === index ? { ...stat, [field]: value } : stat,
        ),
      },
    }))
  }

  const updateCategory = (categoryId, field, value) => {
    const nextData = {
      ...data,
      categories: data.categories.map((category) =>
        category.id === categoryId
          ? { ...category, [field]: value }
          : category,
      ),
    }
    persist(nextData)
  }

  const saveHeroSection = () => {
    persist(data, 'معلومات بخش بالای صفحه محصولات ذخیره شد.')
  }

  const saveCatalogSettings = () => {
    persist(data, 'تنظیمات کاتالوگ محصولات ذخیره شد.')
  }

  const filteredProducts = useMemo(() => {
    const query = searchTerm.trim().toLowerCase()
    if (!query) return data.products

    return data.products.filter((product) =>
      `${product.name} ${product.categoryLabel} ${product.finish} ${product.coverage}`
        .toLowerCase()
        .includes(query),
    )
  }, [data.products, searchTerm])

  const openAddProduct = () => {
    setDraft({
      ...emptyProduct,
      order: data.products.length + 1,
    })
    setModalOpen(true)
  }

const openEditProduct = (product) => {
  const productColors = Array.isArray(product.colors)
    ? product.colors
    : []

  setDraft({
    ...emptyProduct,
    ...product,

    sizesText: Array.isArray(product.sizes)
      ? product.sizes.join('\n')
      : '',

    colorsText: productColors.join('\n'),

    selectedColor:
      productColors[0] || '#ff6b1a',
  })

  setModalOpen(true)
}

  const closeModal = () => {
    setModalOpen(false)
    setDraft(emptyProduct)
  }

  const setDraftField = (field, value) => {
    setDraft((current) => ({
      ...current,
      [field]: value,
    }))
  }

  const normalizeHexColor = (color) => {
  const value = String(color || '').trim().toLowerCase()

  if (/^#[0-9a-f]{6}$/i.test(value)) {
    return value
  }

  return null
}

const getDraftColors = () =>
  draft.colorsText
    .split(/\n|,/)
    .map((color) => normalizeHexColor(color))
    .filter(Boolean)

const addSelectedColor = () => {
  const selectedColor =
    normalizeHexColor(draft.selectedColor) || '#ff6b1a'

  const currentColors = getDraftColors()

  if (currentColors.includes(selectedColor)) {
    window.alert('این رنگ قبلاً اضافه شده است.')
    return
  }

  const nextColors = [
    ...currentColors,
    selectedColor,
  ]

  setDraftField(
    'colorsText',
    nextColors.join('\n'),
  )
}

const removeDraftColor = (colorToRemove) => {
  const nextColors = getDraftColors().filter(
    (color) => color !== colorToRemove,
  )

  setDraftField(
    'colorsText',
    nextColors.join('\n'),
  )
}

const handleColorPickerChange = (event) => {
  const selectedColor = event.target.value

  setDraftField('selectedColor', selectedColor)
}

const handleColorPickerBlur = () => {
  const selectedColor =
    normalizeHexColor(draft.selectedColor)

  if (selectedColor) {
    setDraftField('selectedColor', selectedColor)
  }
}

  const handleCategoryChange = (categoryId) => {
    const category =
      data.categories.find((item) => item.id === categoryId) ||
      productCategoryOptions.find((item) => item.id === categoryId)

    setDraft((current) => ({
      ...current,
      category: categoryId,
      categoryLabel: category?.label || categoryId,
    }))
  }

  const handleImageFile = (event) => {
    const file = event.target.files?.[0]
    event.target.value = ''
    if (!file) return

    if (!file.type.startsWith('image/')) {
      window.alert('فقط فایل تصویری انتخاب کنید.')
      return
    }

    const reader = new FileReader()
    reader.onload = () => setDraftField('image', String(reader.result || ''))
    reader.readAsDataURL(file)
  }

  const saveProduct = (event) => {
    event.preventDefault()

    if (!draft.name.trim()) {
      window.alert('نام محصول را وارد کنید.')
      return
    }

    if (!draft.image.trim()) {
      window.alert('تصویر محصول را انتخاب کنید.')
      return
    }

    const sizes = draft.sizesText
      .split(/\n|,/)
      .map((item) => item.trim())
      .filter(Boolean)
const colorEntries = draft.colorsText
  .split(/\n|,/)
  .map((item) => item.trim())
  .filter(Boolean)

const invalidColors = colorEntries.filter(
  (color) => !/^#[0-9a-f]{6}$/i.test(color),
)

if (invalidColors.length > 0) {
  window.alert(
    `کد رنگ نامعتبر است:\n${invalidColors.join(
      '\n',
    )}\n\nکد رنگ باید مانند #ff6b1a باشد.`,
  )

  return
}

const colors = [
  ...new Set(
    colorEntries.map((color) =>
      color.toLowerCase(),
    ),
  ),
]

    const product = {
      id: draft.id || Date.now(),
      name: draft.name.trim(),
      category: draft.category,
      categoryLabel: draft.categoryLabel.trim(),
      description: draft.description.trim(),
      sizes,
      finish: draft.finish.trim(),
      coverage: draft.coverage.trim(),
      image: draft.image.trim(),
      colors: colors.length ? colors : ['#ffffff'],
      featured: Boolean(draft.featured),
      active: Boolean(draft.active),
      order: Number(draft.order || 0),
    }

    const nextProducts = draft.id
      ? data.products.map((item) =>
          String(item.id) === String(draft.id) ? product : item,
        )
      : [...data.products, product]

    let nextHero = data.hero
    if (!data.hero.featuredProductId) {
      nextHero = { ...data.hero, featuredProductId: product.id }
    }

    persist(
      {
        ...data,
        hero: nextHero,
        products: nextProducts,
      },
      draft.id ? 'محصول ویرایش شد.' : 'محصول جدید اضافه شد.',
    )

    closeModal()
  }

  const toggleProduct = (productId) => {
    persist({
      ...data,
      products: data.products.map((product) =>
        String(product.id) === String(productId)
          ? { ...product, active: product.active === false }
          : product,
      ),
    })
  }

  const setFeaturedProduct = (productId) => {
    persist({
      ...data,
      hero: {
        ...data.hero,
        featuredProductId: productId,
      },
    })
  }

  const confirmDeleteProduct = () => {
    if (!deleteTarget) return

    const nextProducts = data.products.filter(
      (product) => String(product.id) !== String(deleteTarget.id),
    )

    persist(
      {
        ...data,
        products: nextProducts,
        hero: {
          ...data.hero,
          featuredProductId:
            String(data.hero.featuredProductId) === String(deleteTarget.id)
              ? nextProducts[0]?.id || null
              : data.hero.featuredProductId,
        },
      },
      'محصول حذف شد.',
    )

    setDeleteTarget(null)
  }

  const restoreDefaults = () => {
    if (!window.confirm('تمام معلومات محصولات به حالت اولیه برگردد؟')) return
    const nextData = resetProductsData()
    setData(nextData)
  }

  return (
    <div className="products-admin">
      <div className="products-admin-section-tabs">
        <button
          type="button"
          className={section === 'hero' ? 'active' : ''}
          onClick={() => setSection('hero')}
        >
          <LayoutTemplate size={18} />
          بخش بالای صفحه
        </button>

        <button
          type="button"
          className={section === 'catalog' ? 'active' : ''}
          onClick={() => setSection('catalog')}
        >
          <PackagePlus size={18} />
          کاتالوگ محصولات
        </button>

        <button
          type="button"
          className="products-admin-reset"
          onClick={restoreDefaults}
        >
          <RotateCcw size={16} />
          بازگردانی معلومات اولیه
        </button>
      </div>

      {section === 'hero' && (
        <div className="products-admin-hero-layout">
          <section className="products-admin-card">
            <header>
              <div>
                <h3>متن‌های بخش معرفی محصولات</h3>
                <p>عنوان، توضیح و نوشته پس‌زمینه بخش اول صفحه.</p>
              </div>
            </header>

            <div className="products-admin-form-grid">
              <label>
                <span>نوشته کوچک بالا</span>
                <input
                  value={data.hero.kicker}
                  onChange={(event) => updateHero('kicker', event.target.value)}
                />
              </label>

              <label>
                <span>قسمت اول عنوان</span>
                <input
                  value={data.hero.titleBefore}
                  onChange={(event) =>
                    updateHero('titleBefore', event.target.value)
                  }
                />
              </label>

              <label>
                <span>قسمت رنگی عنوان</span>
                <input
                  value={data.hero.titleHighlight}
                  onChange={(event) =>
                    updateHero('titleHighlight', event.target.value)
                  }
                />
              </label>

              <label>
                <span>نوشته بزرگ پس‌زمینه</span>
                <input
                  value={data.hero.backgroundWord}
                  onChange={(event) =>
                    updateHero('backgroundWord', event.target.value)
                  }
                  dir="ltr"
                />
              </label>

              <label className="products-admin-full-field">
                <span>توضیحات</span>
                <textarea
                  rows="4"
                  value={data.hero.description}
                  onChange={(event) =>
                    updateHero('description', event.target.value)
                  }
                />
              </label>
            </div>
          </section>

          <section className="products-admin-card">
            <header>
              <div>
                <h3>آمار بخش محصولات</h3>
                <p>سه کارت آماری نمایش‌داده‌شده در بخش بالای صفحه.</p>
              </div>
            </header>

            <div className="products-admin-stats-editor">
              {data.hero.stats.map((stat, index) => (
                <article key={stat.id}>
                  <strong>آمار {index + 1}</strong>

                  <label>
                    <span>مقدار</span>
                    <input
                      value={stat.value}
                      onChange={(event) =>
                        updateHeroStat(index, 'value', event.target.value)
                      }
                    />
                  </label>

                  <label>
                    <span>عنوان</span>
                    <input
                      value={stat.label}
                      onChange={(event) =>
                        updateHeroStat(index, 'label', event.target.value)
                      }
                    />
                  </label>
                </article>
              ))}
            </div>
          </section>

          <section className="products-admin-card products-admin-featured-card">
            <header>
              <div>
                <h3>محصول ویژه بخش اول</h3>
                <p>محصولی که در کارت تصویری بزرگ بالای صفحه نشان داده می‌شود.</p>
              </div>
            </header>

            <div className="products-admin-form-grid">
              <label>
                <span>محصول ویژه</span>
                <select
                  value={data.hero.featuredProductId || ''}
                  onChange={(event) =>
                    updateHero('featuredProductId', event.target.value)
                  }
                >
                  {data.products.map((product) => (
                    <option key={product.id} value={product.id}>
                      {product.name}
                    </option>
                  ))}
                </select>
              </label>

              <label>
                <span>نوشته روی کارت</span>
                <input
                  value={data.hero.featuredBadge}
                  onChange={(event) =>
                    updateHero('featuredBadge', event.target.value)
                  }
                />
              </label>
            </div>
          </section>

          <div className="products-admin-save-row">
            <button type="button" onClick={saveHeroSection}>
              <Save size={17} />
              ذخیره بخش بالای صفحه
            </button>
          </div>
        </div>
      )}

      {section === 'catalog' && (
        <>
          <section className="products-admin-card products-admin-catalog-settings">
            <header>
              <div>
                <h3>عنوان‌های کاتالوگ</h3>
                <p>متن‌های بالای لیست محصولات و پیام نتیجه خالی.</p>
              </div>

              <button type="button" onClick={saveCatalogSettings}>
                <Save size={16} />
                ذخیره تنظیمات
              </button>
            </header>

            <div className="products-admin-form-grid">
              <label>
                <span>نوشته کوچک</span>
                <input
                  value={data.catalog.kicker}
                  onChange={(event) =>
                    updateCatalog('kicker', event.target.value)
                  }
                />
              </label>

              <label>
                <span>عنوان کاتالوگ</span>
                <input
                  value={data.catalog.title}
                  onChange={(event) =>
                    updateCatalog('title', event.target.value)
                  }
                />
              </label>

              <label>
                <span>Placeholder جستجو</span>
                <input
                  value={data.catalog.searchPlaceholder}
                  onChange={(event) =>
                    updateCatalog('searchPlaceholder', event.target.value)
                  }
                />
              </label>

              <label>
                <span>عنوان نتیجه خالی</span>
                <input
                  value={data.catalog.emptyTitle}
                  onChange={(event) =>
                    updateCatalog('emptyTitle', event.target.value)
                  }
                />
              </label>

              <label className="products-admin-full-field">
                <span>توضیح نتیجه خالی</span>
                <input
                  value={data.catalog.emptyDescription}
                  onChange={(event) =>
                    updateCatalog('emptyDescription', event.target.value)
                  }
                />
              </label>
            </div>
          </section>

          <section className="products-admin-card products-admin-categories-card">
            <header>
              <div>
                <h3>دسته‌بندی‌های فیلتر</h3>
                <p>نام و وضعیت دکمه‌های دسته‌بندی در صفحه محصولات.</p>
              </div>
            </header>

            <div className="products-admin-category-list">
              {data.categories.map((category) => (
                <article key={category.id}>
                  <span>{category.id}</span>

                  <input
                    value={category.label}
                    onChange={(event) =>
                      updateCategory(category.id, 'label', event.target.value)
                    }
                  />

                  <label className="products-admin-switch">
                    <input
                      type="checkbox"
                      checked={category.active !== false}
                      onChange={(event) =>
                        updateCategory(
                          category.id,
                          'active',
                          event.target.checked,
                        )
                      }
                    />
                    <i />
                    <b>{category.active !== false ? 'فعال' : 'غیرفعال'}</b>
                  </label>
                </article>
              ))}
            </div>
          </section>

          <div className="products-admin-products-toolbar">
            <div>
              <strong>لیست محصولات</strong>
              <span>{data.products.length} محصول ثبت شده است.</span>
            </div>

            <button type="button" onClick={openAddProduct}>
              <Plus size={17} />
              افزودن محصول
            </button>
          </div>

          <div className="products-admin-grid">
            {filteredProducts.map((product) => (
              <article
                key={product.id}
                className={product.active === false ? 'is-disabled' : ''}
              >
                <div className="products-admin-product-image">
                  <img src={product.image} alt={product.name} />

                  {String(data.hero.featuredProductId) === String(product.id) && (
                    <span>
                      <Star size={13} fill="currentColor" />
                      محصول بخش اول
                    </span>
                  )}

                  <b>{product.categoryLabel}</b>
                </div>

                <div className="products-admin-product-content">
                  <small>{product.finish || 'بدون نوع پوشش'}</small>
                  <h3>{product.name}</h3>
                  <p>{product.description}</p>

                  <div>
                    <span>{product.coverage || 'پوشش‌دهی ثبت نشده'}</span>
                    <strong>
                      {product.active === false ? 'غیرفعال' : 'فعال'}
                    </strong>
                  </div>
                </div>

                <footer>
                  <button
                    type="button"
                    title="انتخاب برای بخش اول"
                    onClick={() => setFeaturedProduct(product.id)}
                  >
                    <Star size={16} />
                  </button>

                  <button
                    type="button"
                    title={product.active === false ? 'فعال‌سازی' : 'غیرفعال‌سازی'}
                    onClick={() => toggleProduct(product.id)}
                  >
                    <Check size={16} />
                  </button>

                  <button
                    type="button"
                    title="ویرایش"
                    onClick={() => openEditProduct(product)}
                  >
                    <Pencil size={16} />
                  </button>

                  <button
                    type="button"
                    className="danger"
                    title="حذف"
                    onClick={() => setDeleteTarget(product)}
                  >
                    <Trash2 size={16} />
                  </button>
                </footer>
              </article>
            ))}
          </div>
        </>
      )}

      {modalOpen && (
        <div className="products-admin-backdrop" role="presentation">
          <form className="products-admin-modal" onSubmit={saveProduct}>
            <header>
              <div>
                <h2>{draft.id ? 'ویرایش محصول' : 'افزودن محصول جدید'}</h2>
                <p>تمام معلومات کارت محصول را وارد کنید.</p>
              </div>

              <button type="button" onClick={closeModal}>
                <X size={20} />
              </button>
            </header>

            <div className="products-admin-modal-layout">
              <aside>
                <button
                  type="button"
                  className="products-admin-upload"
                  onClick={() => imageInputRef.current?.click()}
                >
                  {draft.image ? (
                    <img src={draft.image} alt="پیش‌نمایش محصول" />
                  ) : (
                    <>
                      <ImagePlus size={34} />
                      <strong>انتخاب تصویر</strong>
                      <span>JPG، PNG یا WEBP</span>
                    </>
                  )}
                </button>

                <input
                  ref={imageInputRef}
                  type="file"
                  accept="image/*"
                  hidden
                  onChange={handleImageFile}
                />

                <label>
                  <span>یا آدرس تصویر</span>
                  <input
                    value={draft.image}
                    onChange={(event) =>
                      setDraftField('image', event.target.value)
                    }
                    dir="ltr"
                    placeholder="https://..."
                  />
                </label>
              </aside>

              <div className="products-admin-form-grid">
                <label>
                  <span>نام محصول *</span>
                  <LocalizedField
  label="نام محصول"
  required
  value={draft.name}
  onChange={(value) =>
    setDraftField('name', value)
  }
  placeholder={{
    fa: 'نام محصول به دری',
    ps: 'د محصول نوم په پښتو',
    en: 'Product name in English',
  }}
/>
                </label>

                <label>
                  <span>دسته‌بندی *</span>
                  <select
                    value={draft.category}
                    onChange={(event) =>
                      handleCategoryChange(event.target.value)
                    }
                  >
                    {data.categories
                      .filter((category) => category.id !== 'all')
                      .map((category) => (
                        <option key={category.id} value={category.id}>
                          {category.label}
                        </option>
                      ))}
                  </select>
                </label>

                <label>
                  <span>عنوان دسته‌بندی روی کارت</span>
                  <input
                    value={draft.categoryLabel}
                    onChange={(event) =>
                      setDraftField('categoryLabel', event.target.value)
                    }
                  />
                </label>

                <label>
                  <span>نوع پوشش</span>
                  <input
                    value={draft.finish}
                    onChange={(event) =>
                      setDraftField('finish', event.target.value)
                    }
                    placeholder="مثلاً مات مخملی"
                  />
                </label>

                <label>
                  <span>پوشش‌دهی</span>
                  <input
                    value={draft.coverage}
                    onChange={(event) =>
                      setDraftField('coverage', event.target.value)
                    }
                    placeholder="مثلاً ۹ تا ۱۱ متر مربع"
                  />
                </label>

                <label>
                  <span>ترتیب نمایش</span>
                  <input
                    type="number"
                    min="0"
                    value={draft.order}
                    onChange={(event) =>
                      setDraftField('order', event.target.value)
                    }
                  />
                </label>

                <label className="products-admin-full-field">
                  <span>توضیحات</span>
                 <LocalizedField
  label="توضیحات"
  multiline
  rows={4}
  value={draft.description}
  onChange={(value) =>
    setDraftField(
      'description',
      value,
    )
  }
/>
                </label>

                <label>
                  <span>اندازه‌ها؛ هر مورد در یک خط</span>
                  <textarea
                    rows="5"
                    value={draft.sizesText}
                    onChange={(event) =>
                      setDraftField('sizesText', event.target.value)
                    }
                    placeholder={'۴ کیلو\n۱۲ کیلو\n۲۰ کیلو'}
                  />
                </label>

              <div className="products-admin-colors-field">
  <span className="products-admin-field-label">
    رنگ‌های محصول
  </span>

  <div className="products-admin-color-picker-row">
    <label className="products-admin-color-picker">
      <input
        type="color"
        value={draft.selectedColor || '#ff6b1a'}
        onChange={handleColorPickerChange}
        aria-label="انتخاب رنگ محصول"
      />

      <span
        className="products-admin-color-preview"
        style={{
          backgroundColor:
            draft.selectedColor || '#ff6b1a',
        }}
      />
    </label>

    <input
      type="text"
      className="products-admin-color-code-input"
      value={draft.selectedColor || ''}
      onChange={(event) =>
        setDraftField(
          'selectedColor',
          event.target.value,
        )
      }
      onBlur={handleColorPickerBlur}
      placeholder="#ff6b1a"
      dir="ltr"
      maxLength={7}
    />

    <button
      type="button"
      className="products-admin-add-color"
      onClick={addSelectedColor}
    >
      افزودن رنگ
    </button>
  </div>

  <div className="products-admin-selected-colors">
    {getDraftColors().length > 0 ? (
      getDraftColors().map((color) => (
        <div
          className="products-admin-selected-color"
          key={color}
        >
          <span
            className="products-admin-selected-color-preview"
            style={{
              backgroundColor: color,
            }}
          />

          <code>{color}</code>

          <button
            type="button"
            onClick={() =>
              removeDraftColor(color)
            }
            aria-label={`حذف رنگ ${color}`}
            title="حذف رنگ"
          >
            ×
          </button>
        </div>
      ))
    ) : (
      <p className="products-admin-no-colors">
        هنوز رنگی انتخاب نشده است.
      </p>
    )}
  </div>

  <textarea
    className="products-admin-colors-textarea"
    rows="4"
    value={draft.colorsText}
    onChange={(event) =>
      setDraftField(
        'colorsText',
        event.target.value,
      )
    }
    placeholder={'#ffffff\n#ff6b1a'}
    dir="ltr"
  />
</div>

                <label className="products-admin-checkbox">
                  <input
                    type="checkbox"
                    checked={draft.featured}
                    onChange={(event) =>
                      setDraftField('featured', event.target.checked)
                    }
                  />
                  <span>نمایش نشان پرفروش روی کارت</span>
                </label>

                <label className="products-admin-checkbox">
                  <input
                    type="checkbox"
                    checked={draft.active}
                    onChange={(event) =>
                      setDraftField('active', event.target.checked)
                    }
                  />
                  <span>محصول فعال و قابل نمایش باشد</span>
                </label>
              </div>
            </div>

            <footer>
              <button type="button" className="secondary" onClick={closeModal}>
                انصراف
              </button>

              <button type="submit" className="primary">
                <Save size={16} />
                ذخیره محصول
              </button>
            </footer>
          </form>
        </div>
      )}

      {deleteTarget && (
        <div className="products-admin-backdrop">
          <div className="products-admin-delete-modal">
            <span>
              <Trash2 size={25} />
            </span>
            <h3>حذف محصول</h3>
            <p>
              آیا محصول «{deleteTarget.name}» حذف شود؟ این عمل قابل برگشت نیست.
            </p>

            <div>
              <button type="button" onClick={() => setDeleteTarget(null)}>
                انصراف
              </button>
              <button type="button" onClick={confirmDeleteProduct}>
                حذف
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default ProductsAdmin