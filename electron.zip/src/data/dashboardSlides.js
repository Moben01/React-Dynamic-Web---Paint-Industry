import { CMS_EVENT, DEFAULT_CMS, getCMS, resetCMS, saveCMS } from './cmsData'
export const UPDATED_EVENT = CMS_EVENT
export const HERO_UPDATED_EVENT = CMS_EVENT
export const PROJECTS_UPDATED_EVENT = CMS_EVENT
export const PROJECTS_CONTENT_UPDATED_EVENT = CMS_EVENT
export const DEFAULT_SLIDES = DEFAULT_CMS.slides
export const DEFAULT_HERO_CONTENT = DEFAULT_CMS.dashboard
export const DEFAULT_PROJECTS = DEFAULT_CMS.projects
export function getSlides() { return getCMS('slides') }
export function getActiveSlides() { return getCMS('slides').filter(x => x.active !== false && x.image).sort((a, b) => (a.order || 0) - (b.order || 0)) }
export function saveSlides(v) { return saveCMS('slides', v) }
export function resetSlides() { return resetCMS('slides') }
export function getHeroContent() { const d = getCMS('dashboard'); return { ...d, titleBefore: d.title, titleHighlight: d.highlight, changingPrefix: d.rotatingPrefix } }
export function saveHeroContent(v) { return saveCMS('dashboard', { ...v, title: v.titleBefore || v.title, highlight: v.titleHighlight || v.highlight, rotatingPrefix: v.changingPrefix || v.rotatingPrefix }) }
export function resetHeroContent() { return resetCMS('dashboard') }
export function getProjects() { return getCMS('projects') }
export function getActiveProjects() { return getCMS('projects').filter(x => x.active !== false && x.image).sort((a, b) => (a.order || 0) - (b.order || 0)) }
export function saveProjects(v) { return saveCMS('projects', v) }
export function resetProjects() { return resetCMS('projects') }
export function getProjectsContent() { const p = getCMS('dashboard'); return { eyebrow: p.projectsEyebrow, titleBefore: p.projectsTitle, titleHighlight: p.projectsHighlight, description: p.projectsDescription, hint: 'برای مشاهده جزئیات روی پروژه کلیک کنید' } }
export function saveProjectsContent(v) { const p = getCMS('dashboard'); return saveCMS('dashboard', { ...p, projectsEyebrow: v.eyebrow, projectsTitle: v.titleBefore, projectsHighlight: v.titleHighlight, projectsDescription: v.description }) }
export const getAllDashboardSlides = getSlides
export const getActiveDashboardSlides = getActiveSlides
export const saveDashboardSlides = saveSlides
export const resetDashboardSlides = resetSlides
export const getDashboardHeroContent = getHeroContent
export const saveDashboardHeroContent = saveHeroContent
export const resetDashboardHeroContent = resetHeroContent
export const DASHBOARD_HERO_UPDATED_EVENT = HERO_UPDATED_EVENT
